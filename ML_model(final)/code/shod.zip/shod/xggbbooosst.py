import pandas as pd
from sklearn.model_selection import cross_val_predict
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.metrics import classification_report, confusion_matrix
from xgboost import XGBClassifier

# Load data
data_path = "code/shod/cleaned_car_data.csv"
df = pd.read_csv(data_path)

# Create price_category (target)
bins = [0, 15000, 30000, float('inf')]
labels = ['low', 'mid', 'high']
df['price_category'] = pd.cut(df['price'], bins=bins, labels=labels)

# Fill missing engine_size
df['engine_size'] = df['engine_size'].fillna(df['engine_size'].median())

# Encode string labels to integers
label_map = {'low': 0, 'mid': 1, 'high': 2}
inverse_label_map = {v: k for k, v in label_map.items()}
df['price_category'] = df['price_category'].map(label_map)

# Define features and target
X = df.drop(['price', 'price_category'], axis=1)
y = df['price_category']

# Column groups
categorical_cols = ['brand', 'model', 'fuel_type', 'transmission', 'ext_col', 'int_col']
numeric_cols = ['model_year', 'milage', 'accident', 'clean_title', 'engine_size', 'car_age']

# Preprocessing
preprocessor = ColumnTransformer([
    ('num', StandardScaler(), numeric_cols),
    ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_cols)
])

# XGBoost pipeline
xgb_pipeline = Pipeline([
    ('preprocessor', preprocessor),
    ('classifier', XGBClassifier(
        n_estimators=100,
        learning_rate=0.1,
        max_depth=6,
        use_label_encoder=False,
        eval_metric='mlogloss',
        random_state=42
    ))
])

# Cross-validated predictions
y_pred = cross_val_predict(xgb_pipeline, X, y, cv=5)

# Decode predictions and actuals back to original labels
y_pred_labels = [inverse_label_map[i] for i in y_pred]
y_true_labels = [inverse_label_map[i] for i in y]

# Evaluation
print("\n🚀 Classification Report:")
print(classification_report(y_true_labels, y_pred_labels))

print("\n🧮 Confusion Matrix:")
print(confusion_matrix(y_true_labels, y_pred_labels))
