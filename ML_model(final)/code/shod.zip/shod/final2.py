import pandas as pd
import numpy as np
from sklearn.model_selection import cross_val_predict
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix

# ---------- Load Data ----------
df = pd.read_csv("code/shod/cleaned_car_data.csv")  # ✅ Update path if needed

# ---------- Create Price Categories ----------
bins = [0, 15000, 30000, float('inf')]
labels = ['low', 'mid', 'high']
df['price_category'] = pd.cut(df['price'], bins=bins, labels=labels)

# ---------- Handle Missing Values ----------
df['engine_size'] = df['engine_size'].fillna(df['engine_size'].median())

# ---------- Use 6 Key Features Including `model` ----------
X = df[['brand', 'model', 'model_year', 'milage', 'fuel_type', 'engine_size']]
y = df['price_category']

# ---------- Column Types ----------
categorical_cols = ['brand', 'model', 'fuel_type']
numeric_cols = ['model_year', 'milage', 'engine_size']

# ---------- Preprocessor ----------
preprocessor = ColumnTransformer([
    ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_cols),
    ('num', StandardScaler(), numeric_cols)
])

# ---------- Pipeline ----------
pipeline = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('classifier', RandomForestClassifier(n_estimators=100, random_state=42))
])

# ---------- Cross-validated Predictions ----------
y_pred = cross_val_predict(pipeline, X, y, cv=5)

# ---------- Evaluation ----------
print("\n📊 Classification Report:")
print(classification_report(y, y_pred))

print("\n🧮 Confusion Matrix:")
print(confusion_matrix(y, y_pred))

# ---------- Predict Price from User Input ----------
print("\n🎯 Let's estimate your car's price category and future value...\n")

# 🧾 User Input
brand = input("Brand: ")
model = input("Model: ")
year = int(input("Model Year: "))
milage = float(input("Mileage (in km): "))
fuel_type = input("Fuel Type (Petrol/Diesel/Electric/Hybrid): ")
engine_size = float(input("Engine Size (in L): "))

# Optional tax rate
try:
    tax_input = input("Enter tax rate (e.g., 0.18 for 18%) [Default = 0.18]: ")
    tax_rate = float(tax_input) if tax_input.strip() else 0.18
except:
    tax_rate = 0.18

print(f"\nUsing tax rate: {tax_rate * 100:.1f}%")

# 🔍 Build input DataFrame
input_data = pd.DataFrame([{
    'brand': brand,
    'model': model,
    'model_year': year,
    'milage': milage,
    'fuel_type': fuel_type,
    'engine_size': engine_size
}])

# 🔍 Train model on full data
pipeline.fit(X, y)
category = pipeline.predict(input_data)[0]
print(f"\n📌 Predicted Price Category: **{category.upper()}**")

# Estimate average price based on category
avg_prices = {
    'low': 10000,
    'mid': 22000,
    'high': 38000
}
base_price = avg_prices[category]

# ---------- Future Depreciation Estimation ----------
def depreciate(value, years, rate=0.12):
    return value * ((1 - rate) ** years)

years_list = [5, 8, 10]
print("\n📉 Estimated future values with 12% yearly depreciation:")
for yrs in years_list:
    value = depreciate(base_price, yrs)
    taxed = value * (1 + tax_rate)
    print(f"  ➤ In {yrs} years: ₹{value:,.2f} (+tax: ₹{taxed:,.2f})")