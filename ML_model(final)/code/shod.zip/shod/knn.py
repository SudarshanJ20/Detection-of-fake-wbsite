import pandas as pd
from sklearn.model_selection import cross_val_predict
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import classification_report, confusion_matrix

# Load data
data_path = "code/shod/cleaned_car_data.csv"
df = pd.read_csv(data_path)

# Create price_category labels
bins = [0, 15000, 30000, float('inf')]
labels = ['low', 'mid', 'high']
df['price_category'] = pd.cut(df['price'], bins=bins, labels=labels)

# Fill missing engine_size
df['engine_size'] = df['engine_size'].fillna(df['engine_size'].median())

# Define features and target
X = df.drop(['price', 'price_category'], axis=1)
y = df['price_category']

# Columns
categorical_cols = ['brand', 'model', 'fuel_type', 'transmission', 'ext_col', 'int_col']
numeric_cols = ['model_year', 'milage', 'accident', 'clean_title', 'engine_size', 'car_age']

# Preprocessing pipeline
preprocessor = ColumnTransformer([
    ('num', StandardScaler(), numeric_cols),
    ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_cols)
])

# KNN pipeline
knn_pipeline = Pipeline([
    ('preprocessor', preprocessor),
    ('classifier', KNeighborsClassifier(n_neighbors=5))  # You can tune this
])

# Cross-validated predictions
y_pred = cross_val_predict(knn_pipeline, X, y, cv=5)

# Evaluation
print("\n📊 Classification Report:")
print(classification_report(y, y_pred))

print("\n🧮 Confusion Matrix:")
print(confusion_matrix(y, y_pred))
