import pandas as pd

data = "code/shod/cleaned_car_data.csv"
df = pd.read_csv(data)

print(df.head())
print(df.info())

