import pandas as pd
from sklearn.model_selection import cross_val_predict
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix

# ---------- Load Data ----------
df = pd.read_csv("code/shod/cleaned_car_data.csv")  # UPDATE THIS

# ---------- Create Price Categories ----------
bins = [0, 15000, 30000, float('inf')]
labels = ['low', 'mid', 'high']
df['price_category'] = pd.cut(df['price'], bins=bins, labels=labels)

# ---------- Handle Missing Values ----------
df['engine_size'] = df['engine_size'].fillna(df['engine_size'].median())

# ---------- Define Features and Target ----------
X = df.drop(['price', 'price_category'], axis=1)
y = df['price_category']

# ---------- Categorical and Numeric Columns ----------
categorical_cols = ['brand', 'model', 'fuel_type', 'transmission', 'ext_col', 'int_col']
numeric_cols = ['model_year', 'milage', 'accident', 'clean_title', 'engine_size', 'car_age']

# ---------- Preprocessing ----------
preprocessor = ColumnTransformer(
    transformers=[
        ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_cols),
        ('num', StandardScaler(), numeric_cols)
    ]
)

# ---------- Pipeline ----------
model = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('classifier', RandomForestClassifier(n_estimators=100, random_state=42))
])

# ---------- Cross-validated Predictions ----------
y_pred = cross_val_predict(model, X, y, cv=5)

# ---------- Evaluation ----------
print("\nClassification Report:")
print(classification_report(y, y_pred))

print("\nConfusion Matrix:")
print(confusion_matrix(y, y_pred))
