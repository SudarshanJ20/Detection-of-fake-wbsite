import pandas as pd
import re

# Load raw data
df = pd.read_csv("code/shod/used_cars.csv")  # Change this to your raw file name

# ----- Clean 'price' -----
df['price'] = df['price'].replace('[\$,]', '', regex=True).astype(float)

# ----- Clean 'milage' -----
df['milage'] = df['milage'].str.replace(',', '').str.extract('(\d+)').astype(float)

# ----- Extract engine size -----
df['engine_size'] = df['engine'].str.extract(r'([0-9.]+)').astype(float)

# ----- Calculate car age -----
df['car_age'] = 2025 - df['model_year']

# ----- Clean 'clean_title' -----
df['clean_title'] = df['clean_title'].fillna('No')
df['clean_title'] = df['clean_title'].apply(lambda x: 1 if x.strip().lower() == 'yes' else 0)

# ----- Clean 'accident' -----
df['accident'] = df['accident'].fillna('No')
df['accident'] = df['accident'].apply(lambda x: 1 if x.strip().lower() == 'yes' else 0)

# ----- Drop rows with missing essential values -----
df = df.dropna(subset=['fuel_type', 'transmission'])

# ----- Optional: Drop original 'engine' column -----
df = df.drop(columns=['engine'])

# ----- Save cleaned data -----
df.to_csv("code/shod/cleaned_car_data.csv", index=False)

print("✅ Data cleaned and saved to 'cleaned_car_data.csv'")
